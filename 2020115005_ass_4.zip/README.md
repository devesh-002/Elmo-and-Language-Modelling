# README

The one drive link for pretrained models and embeddings can be found [here](https://iiitaphyd-my.sharepoint.com/:f:/g/personal/devesh_marwah_research_iiit_ac_in/EojD7orR1MVCkRrnJyuW6qMBSd5PEjqX7CmY1JmJWoP0SA?e=MeBOVR)

https://iiitaphyd-my.sharepoint.com/:f:/g/personal/devesh_marwah_research_iiit_ac_in/EojD7orR1MVCkRrnJyuW6qMBSd5PEjqX7CmY1JmJWoP0SA?e=CJLWCp



It is recommended that you use colab notebook to run the file rather than running the original python file. If you want to test it locally, the ipynb file has been submitted along with it for easy running and analysis.

The link for the colab notebook is [here](https://colab.research.google.com/drive/1U9x8c4z1GKvPhkzfOB8aHQES-6e-OrBi?usp=sharing)

https://colab.research.google.com/drive/1U9x8c4z1GKvPhkzfOB8aHQES-6e-OrBi?usp=sharing

```
python3 final_inlp_ass_4.py
```

